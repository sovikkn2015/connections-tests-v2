/* global React */

/* =========================================================================
 * CLIENT LIAISON — Channel-native (WhatsApp surface)
 * Phone bezel, agent + RM chat, CTAs, disclaimer.
 * Side panes provide context for what's happening in the channel.
 * ========================================================================= */

function ClientLiaison() {
  return (
    <div className="client-stage" data-screen-label="03 Client Liaison Channel">
      <div className="client-grid">
        {/* Left caption */}
        <div className="client-grid__caption">
          <div className="client-grid__caption-eyebrow">Client surface</div>
          <div className="client-grid__caption-title">Channel-native, not a portal.</div>
          <div className="client-grid__caption-body">
            Eleanor opens WhatsApp like she does any morning. The Liaison agent answers FAQs, surfaces a hand-off when an action is required, and never quotes positions or numbers.
          </div>
          <ul className="client-grid__caption-list">
            <li><span><strong>FAQ tier</strong> — Haiku-class. No vendor calls, read-only context.</span></li>
            <li><span><strong>Hand-off tier</strong> — recognises intent shift, queues an Insight in Marcus's workbench.</span></li>
            <li><span><strong>Disclaimer is permanent</strong> — informational only; recommendations route through the RM.</span></li>
            <li><span><strong>MNPI safe</strong> — same trust spine, redactions applied server-side.</span></li>
          </ul>
        </div>

        {/* Phone */}
        <div className="phone">
          <div className="phone__notch"></div>
          <div className="phone__screen">
            <div className="phone__statusbar">
              <span className="w360-mono">9:41</span>
              <span style={{ display: "inline-flex", gap: 4, alignItems: "center" }}>
                <span style={{ fontSize: 11 }}>●●●●● 5G</span>
                <span style={{ fontSize: 11 }}>96%</span>
              </span>
            </div>
            <div className="client-header">
              <span className="client-header__back">‹</span>
              <div className="client-header__avatar">W360</div>
              <div>
                <div className="client-header__name">Your Wealth Team</div>
                <div className="client-header__status">online</div>
              </div>
              <div className="client-header__icons">
                <span>📞</span><span>⋮</span>
              </div>
            </div>

            <div className="client-thread">
              <div className="client-day">TODAY</div>

              <div className="bubble bubble--in">
                Good morning, Eleanor. Markets opened mixed; Asia was choppy on chip-export headlines. I'm here if you have any questions.
                <span className="bubble__time">06:02</span>
              </div>

              <div className="bubble bubble--out">
                Hi! Can you remind me how my portfolio is allocated overall?
                <span className="bubble__time bubble__time--out">06:08</span>
              </div>

              <div className="bubble bubble--in">
                I can share general context, but for specific positions and changes, Marcus (your RM) is the right person — he can pull live numbers and act on them.
                <span className="bubble__time">06:08</span>
              </div>

              <div className="bubble bubble--out">
                Should we be locking some NVDA gains before the print? China headlines make me nervous.
                <span className="bubble__time bubble__time--out">06:09</span>
              </div>

              <div className="bubble bubble--in">
                That's exactly the kind of decision Marcus should weigh in on. Want me to flag it to him now?
                <div className="bubble__rich">
                  <div className="bubble__rich-title">Suggested next step</div>
                  Loop in Marcus Kerrigan with the context above. He'll reply directly here.
                </div>
                <span className="bubble__time">06:10</span>
              </div>

              <div className="bubble bubble--out">
                Yes please.
                <span className="bubble__time bubble__time--out">06:10</span>
              </div>

              <div className="bubble bubble--in">
                Done — Marcus has been notified and will be with you shortly.
                <span className="bubble__time">06:10</span>
              </div>

              <div className="bubble bubble--in">
                <div className="bubble__name">Marcus Kerrigan</div>
                Eleanor — good instinct. NVDA is above your IPS ceiling. Let me pull a trim plan and we'll review together.
                <span className="bubble__time">06:11</span>
              </div>

              <div className="bubble bubble--in">
                <div className="bubble__name">Marcus Kerrigan</div>
                Plan ready. Trimming from 14.2% → 9.5%, redeploying to MAG-7 ex-NVDA. OK to proceed?
                <span className="bubble__time">06:13</span>
              </div>
            </div>

            <div className="client-disclaimer">
              <span style={{ fontSize: 11 }}>ⓘ</span>
              <span>For informational purposes. Your RM makes recommendations.</span>
            </div>

            <div className="client-ctas">
              <button className="cta--primary">📅 Schedule call</button>
              <button className="cta--secondary">👤 Ask my RM</button>
            </div>

            <div className="client-composer">
              <span style={{ color: "#999", fontSize: 18, paddingLeft: 4 }}>☺</span>
              <div className="client-composer__input">Type a message</div>
              <span style={{ color: "#999", fontSize: 18 }}>📎</span>
              <span style={{ color: "#999", fontSize: 18 }}>📷</span>
              <button className="client-composer__send">➤</button>
            </div>
          </div>
        </div>

        {/* Right caption — what happens behind the scenes */}
        <div className="client-grid__caption">
          <div className="client-grid__caption-eyebrow">Behind the scenes</div>
          <div className="client-grid__caption-title">One trust spine. Three surfaces.</div>
          <div className="client-grid__caption-body">
            The Liaison surface looks like a chat to Eleanor — but every turn flows through the same orchestrator, MNPI filter, and audit gate as Sarah's research brief and Marcus's order plan.
          </div>
          <div className="trace-stack">
            <window.TraversalMap persona="client" turnId="b21e-9f04" compact />
            <window.Timeline persona="client" />
          </div>
        </div>
      </div>
    </div>
  );
}

window.ClientLiaison = ClientLiaison;
