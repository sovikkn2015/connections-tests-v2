/* global React */

/* =========================================================================
 * SHARED TRACE COMPONENTS — TraversalMap + Timeline
 * Same visual vocabulary across personas, parameterized by which orchestrator
 * + specialists are lit. Every persona shares the trust spine.
 * ========================================================================= */

/* ---------- Architecture map ---------- */
function TraversalMap({ persona = "research", turnId = "4f8c-2a11", subtitle, compact = false }) {
  // Three orchestrators across the top, specialists fan out below the active one.
  // We always show ALL nodes — only the lit pattern changes by persona.
  const lit = {
    research: {
      orch: "research",
      specs: { market: "solid", filings: "solid", sent: "pulse", compl: "solid", stmt: "solid" },
      mcps: { finnhub: "solid", edgar1: "solid", tavily: "pulse", cscreen: "solid", edgar2: "solid" },
      sub: "persona: research · 5 specialists in parallel",
    },
    advisor: {
      orch: "advisor",
      specs: { action: "pulse", suit: "solid", port: "solid", compl2: "solid" },
      mcps: { oms: "solid", crm: "solid", policy: "solid", muleSoft: "pulse" },
      sub: "persona: advisor · gate ④ HITL hold · plan 9d3a-71fc",
    },
    client: {
      orch: "liaison",
      specs: { faq: "solid", intent: "pulse", handoff: "solid" },
      mcps: { kb: "solid", classifier: "solid", queueIns: "pulse" },
      sub: "persona: liaison · L1 FAQ → intent shift → hand-off",
    },
  }[persona];

  // Layout: 3 orchestrators top, specialists below the active one, MCPs below.
  // Coordinator at center top, three orchs in a row.
  const W = 1240;

  // Top orchestrator row
  const orchY = 8, specY = 76, mcpY = 144;
  const ORCHS = {
    research: { x: 80, label: "research_orch" },
    advisor: { x: 540, label: "advisor_orch" },
    liaison: { x: 1000, label: "liaison_orch" },
  };
  const COORD = { x: 540, y: 8, label: "coordinator", chip: "coordinator" };

  // Specialists per persona (positioned as a fan beneath their orchestrator)
  const SPECS = {
    research: [
      { key: "market", x: 0, label: "market_spec" },
      { key: "filings", x: 95, label: "filings_spec" },
      { key: "sent", x: 190, label: "sentiment" },
      { key: "compl", x: 285, label: "compliance" },
      { key: "stmt", x: 380, label: "statement" },
    ],
    advisor: [
      { key: "action", x: 0, label: "action_spec" },
      { key: "suit", x: 100, label: "suitability" },
      { key: "port", x: 200, label: "portfolio" },
      { key: "compl2", x: 300, label: "compliance" },
    ],
    client: [
      { key: "faq", x: 0, label: "faq_spec" },
      { key: "intent", x: 100, label: "intent_class" },
      { key: "handoff", x: 200, label: "handoff" },
    ],
  };
  const MCPS = {
    research: [
      { key: "finnhub", x: 0, label: "finnhub", kind: "MCP" },
      { key: "edgar1", x: 95, label: "sec-edgar", kind: "MCP" },
      { key: "tavily", x: 190, label: "tavily", kind: "MCP" },
      { key: "cscreen", x: 285, label: "compl-screen", kind: "skill" },
      { key: "edgar2", x: 380, label: "sec-edgar", kind: "MCP" },
    ],
    advisor: [
      { key: "oms", x: 0, label: "oms-prime", kind: "MCP" },
      { key: "crm", x: 100, label: "salesforce", kind: "MCP" },
      { key: "policy", x: 200, label: "ips-policy", kind: "skill" },
      { key: "muleSoft", x: 300, label: "mulesoft", kind: "MCP" },
    ],
    client: [
      { key: "kb", x: 0, label: "kb-tavily", kind: "MCP" },
      { key: "classifier", x: 100, label: "intent-llm", kind: "skill" },
      { key: "queueIns", x: 200, label: "queue-insight", kind: "MCP" },
    ],
  };

  const activeOrch = lit.orch;
  const activeOrchX = ORCHS[activeOrch].x;
  const specs = SPECS[persona].map((s) => ({ ...s, x: s.x + activeOrchX, status: lit.specs[s.key] || "dim" }));
  const mcps = MCPS[persona].map((m) => ({ ...m, x: m.x + activeOrchX, status: lit.mcps[m.key] || "dim" }));

  // Build edges: coord → all 3 orchs (only active is lit), active orch → its specialists, each specialist → its MCP
  const edges = [];
  // Coordinator → orchestrators
  Object.entries(ORCHS).forEach(([k, o]) => {
    edges.push({
      from: { x: COORD.x + 50, y: COORD.y + 22 },
      to: { x: o.x + 50, y: orchY },
      kind: k === activeOrch ? "lit" : "dim",
    });
  });
  // Inter-orchestrator handoff edges (dashed dim) — show the trust spine
  edges.push({
    from: { x: ORCHS.research.x + 100, y: orchY + 11 },
    to: { x: ORCHS.advisor.x, y: orchY + 11 },
    kind: "ghost",
  });
  edges.push({
    from: { x: ORCHS.advisor.x + 100, y: orchY + 11 },
    to: { x: ORCHS.liaison.x, y: orchY + 11 },
    kind: "ghost",
  });
  // Active orch → specs
  specs.forEach((s) => {
    edges.push({
      from: { x: ORCHS[activeOrch].x + 50, y: orchY + 22 },
      to: { x: s.x + 50, y: specY },
      kind: s.status === "pulse" ? "dashed" : "lit",
    });
  });
  // Spec → MCP (paired by index)
  specs.forEach((s, i) => {
    const m = mcps[i];
    if (!m) return;
    edges.push({
      from: { x: s.x + 50, y: specY + 22 },
      to: { x: m.x + 50, y: mcpY },
      kind: m.status === "pulse" ? "dashed" : m.status === "dim" ? "dim" : "lit",
    });
  });

  const height = compact ? 180 : 200;
  const viewH = mcpY + 40;

  return (
    <div className="traversal-map">
      <div className="tm-header">
        <div className="tm-header__title">
          <span>Architecture Map</span>
          <span className="w360-mono" style={{ fontSize: 10, color: "var(--forensic-text-4)", textTransform: "none", letterSpacing: 0 }}>
            {subtitle || `${lit.sub} · turn ${turnId}`}
          </span>
        </div>
        <div className="tm-header__legend">
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#3B4A5F" }}></span>dim</span>
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#1B96FF", boxShadow: "0 0 8px #1B96FF" }}></span>in-flight</span>
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#56D364" }}></span>complete</span>
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#F47067" }}></span>error</span>
        </div>
      </div>
      <div className="tm-canvas" style={{ height }}>
        <svg width="100%" height="100%" viewBox={`0 0 ${W} ${viewH}`} preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
          {edges.map((e, i) => {
            const cls =
              e.kind === "lit" ? "tm-edge tm-edge--lit"
              : e.kind === "dashed" ? "tm-edge--lit-dashed"
              : e.kind === "ghost" ? "tm-edge tm-edge--ghost"
              : "tm-edge";
            const my = (e.from.y + e.to.y) / 2;
            // straight horizontal for ghost handoff edges
            if (e.kind === "ghost") {
              return <path key={i} className={cls} d={`M${e.from.x},${e.from.y} L${e.to.x},${e.to.y}`} />;
            }
            return <path key={i} className={cls} d={`M${e.from.x},${e.from.y} C${e.from.x},${my} ${e.to.x},${my} ${e.to.x},${e.to.y}`} />;
          })}
        </svg>
        {/* Coordinator */}
        <div className="tm-node" data-status="solid" style={{ left: COORD.x, top: COORD.y }}>
          <div className="tm-node__chip">{COORD.chip}</div>
          <div className="tm-node__label">COORDINATOR</div>
        </div>
        {/* Three orchestrators */}
        {Object.entries(ORCHS).map(([k, o]) => (
          <div
            key={k}
            className="tm-node"
            data-status={k === activeOrch ? "pulse" : "dim"}
            style={{ left: o.x, top: orchY + 30 }}
          >
            <div className="tm-node__chip">{o.label}</div>
            <div className="tm-node__label">ORCHESTRATOR</div>
          </div>
        ))}
        {/* Specialists */}
        {specs.map((s) => (
          <div key={s.key} className="tm-node" data-status={s.status} style={{ left: s.x, top: specY }}>
            <div className="tm-node__chip">{s.label}</div>
            <div className="tm-node__label">specialist</div>
          </div>
        ))}
        {/* MCPs / skills */}
        {mcps.map((m) => (
          <div key={m.key} className="tm-node" data-status={m.status} style={{ left: m.x, top: mcpY }}>
            <div className="tm-node__chip">{m.label}</div>
            <div className="tm-node__label">{m.kind}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- End-to-end timeline ---------- */
function Timeline({ persona = "research", title, totalLabel }) {
  const ROWS = {
    research: [
      ["research_orchestrator", "orch", 0, 99, "2310ms"],
      ["├ market_specialist", "skill", 4, 40, "920ms"],
      ["│  └ finnhub-mcp", "mcp", 8, 12, "280ms"],
      ["├ filings_specialist", "skill", 4, 51, "1180ms"],
      ["│  └ sec-edgar-mcp", "mcp", 12, 18, "412ms"],
      ["├ sentiment_specialist", "skill", 5, 36, "840ms"],
      ["│  └ tavily-mcp", "mcp", 9, 15, "340ms"],
      ["├ compliance_specialist", "skill", 4, 27, "620ms"],
      ["│  └ compliance_screen", "skill", 8, 5, "110ms"],
      ["└ statement_specialist", "skill", 5, 57, "1320ms"],
      ["    └ sec-edgar-mcp", "mcp", 14, 21, "490ms"],
    ],
    advisor: [
      ["advisor_orchestrator", "orch", 0, 99, "1840ms"],
      ["├ guardrails (gate ①)", "skill", 0, 4, "80ms"],
      ["├ mnpi_filter (gate ②)", "skill", 4, 3, "60ms"],
      ["├ compliance_screen (gate ③)", "skill", 7, 12, "220ms"],
      ["├ action_specialist", "skill", 19, 38, "710ms"],
      ["│  └ ips-policy", "skill", 23, 6, "120ms"],
      ["│  └ portfolio_optimize", "skill", 30, 24, "440ms"],
      ["│  └ oms-prime-mcp (preview)", "mcp", 40, 9, "180ms"],
      ["└ HITL hold (gate ④)", "human", 58, 41, "11.4s ⏸"],
      ["   ↳ on approve → mulesoft-mcp", "mcp", 99, 1, "queued"],
    ],
    client: [
      ["liaison_orchestrator", "orch", 0, 99, "1240ms"],
      ["├ guardrails", "skill", 0, 4, "60ms"],
      ["├ faq_specialist", "skill", 4, 22, "320ms"],
      ["│  └ kb-tavily-mcp", "mcp", 8, 14, "210ms"],
      ["├ intent_classifier", "skill", 26, 9, "180ms"],
      ["│  └ scope check: 'recommend'", "skill", 30, 4, "ok"],
      ["├ refusal_template", "skill", 35, 6, "110ms"],
      ["└ handoff_specialist", "skill", 41, 28, "560ms"],
      ["   └ queue_insight → advisor", "mcp", 56, 12, "240ms"],
      ["   └ channel-bridge (RM reply)", "mcp", 68, 31, "—"],
    ],
  }[persona];

  const META = {
    research: ["End-to-End Trace", `06:14:30 · "What's happening with NVDA?" · 5 tools · 2.3s`],
    advisor: ["End-to-End Trace", `06:13:42 · "Trim NVDA → 9.5%" · plan held at gate ④ · ⏸ 11.4s HITL`],
    client: ["End-to-End Trace", `06:09:01 · "Should we lock NVDA gains?" · L1 → hand-off · 1.2s`],
  }[persona];

  return (
    <div className="timeline">
      <div className="timeline__header">
        <div className="timeline__header-title">
          <span>{title || META[0]}</span>
          <span className="w360-mono" style={{ fontSize: 10, color: "var(--forensic-text-4)", textTransform: "none", letterSpacing: 0 }}>{totalLabel || META[1]}</span>
        </div>
        <button className="btn-ghost">⎋ open in Langfuse</button>
      </div>
      <div className="timeline__rows">
        {ROWS.map(([name, kind, start, len, lat], i) => (
          <div key={i} className="timeline__row">
            <span className={"timeline__name" + (typeof name === "string" && (name.startsWith("├") || name.startsWith("│") || name.startsWith("└") || name.startsWith("    ") || name.startsWith("   ")) ? " timeline__name--child" : "")}>{name}</span>
            <span className="timeline__type">[{kind}]</span>
            <div className="timeline__bar-track">
              <div className={"timeline__bar timeline__bar--" + kind} style={{ left: `${start}%`, width: `${len}%` }} />
            </div>
            <span className="timeline__latency">{lat}</span>
          </div>
        ))}
      </div>
      <div className="timeline__caption">
        {persona === "research" && (<>All five specialists started at t≈80ms — proves <span className="w360-mono">asyncio.gather</span>. Orchestrator total ≠ Σ children — proves parallelism.</>)}
        {persona === "advisor" && (<>Three policy gates fire before action_spec drafts. Plan halts at gate ④ until RM approves — execution gated, not advisory.</>)}
        {persona === "client" && (<>Intent shift caught client-side — refusal returns before any MCP touch. Hand-off preserves the conversation ID across personas.</>)}
      </div>
    </div>
  );
}

window.TraversalMap = TraversalMap;
window.Timeline = Timeline;
