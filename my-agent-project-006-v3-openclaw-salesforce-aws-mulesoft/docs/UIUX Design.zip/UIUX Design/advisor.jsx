/* global React */

/* =========================================================================
 * RM ADVISOR WORKBENCH — Marcus Kerrigan
 * Light SLDS surface. Seven-gate tracker live, queues / conversation /
 * client context, HITL approval card.
 * ========================================================================= */

function GatesTracker({ activeIdx = 3 }) {
  const gates = [
    { num: "①", name: "Guardrails", detail: "input shape · roles · scope", lat: "80ms" },
    { num: "②", name: "MNPI Filter", detail: "redactions: 2 · ok", lat: "60ms" },
    { num: "③", name: "Compliance", detail: "screen · suitability · ok", lat: "220ms" },
    { num: "④", name: "HITL", detail: "RM approval · pending", lat: "—" },
    { num: "⑤", name: "Dual-Auth", detail: "second approver", lat: "—" },
    { num: "⑥", name: "MuleSoft", detail: "broker / OMS submit", lat: "—" },
    { num: "⑦", name: "Audit", detail: "Langfuse · S3 · CRM", lat: "—" },
  ];
  return (
    <div className="gates" role="progressbar" aria-label="Seven-gate write path">
      {gates.map((g, i) => {
        let status = "pending";
        if (i < activeIdx) status = "passed";
        else if (i === activeIdx) status = "active";
        return (
          <div key={g.name} className="gate" data-status={status}>
            <span className="gate__num">{g.num} gate {i + 1} / 7</span>
            <span className="gate__name">{g.name}</span>
            <span className="gate__detail">{g.detail} · {g.lat}</span>
          </div>
        );
      })}
    </div>
  );
}

function QueuesPanel() {
  const queues = [
    { id: "actions", label: "Actions", count: 3, active: true },
    { id: "demand", label: "Insights", count: 7 },
    { id: "tasks", label: "Tasks", count: 12 },
  ];
  const items = [
    {
      title: "Trim NVDA — Eleanor Vance",
      sub: "Concentration > 12% · pre-earnings",
      time: "06:14",
      priority: "high",
      unread: true,
      selected: true,
    },
    {
      title: "Rebalance · Kapoor Family",
      sub: "Drift 3.2% from policy · SMA",
      time: "05:48",
      priority: "med",
      unread: true,
    },
    {
      title: "Tax-loss harvest · A. Tanaka",
      sub: "VTI lots eligible · $42K loss",
      time: "Yest",
      priority: "med",
    },
    {
      title: "Client check-in · D. Okafor",
      sub: "90-day cadence · scheduled",
      time: "Mon",
      priority: "low",
    },
    {
      title: "ETF swap · Marston Trust",
      sub: "VOO → IVV · cost basis 0.03%",
      time: "Mon",
      priority: "low",
    },
  ];
  return (
    <aside className="advisor-col">
      <div className="queue-tabs" role="tablist">
        {queues.map((q) => (
          <button key={q.id} className="queue-tab" role="tab" aria-selected={q.active}>
            {q.label}
            <span className="queue-tab__count">{q.count}</span>
          </button>
        ))}
      </div>
      <div className="advisor-col__body">
        {items.map((it, i) => (
          <div
            key={i}
            className="queue-item"
            data-unread={it.unread}
            data-selected={it.selected}
          >
            <div className="queue-item__title">
              <span>{it.title}</span>
            </div>
            <div className="queue-item__subtitle">{it.sub}</div>
            <div className="queue-item__meta">
              <span className={"queue-item__priority queue-item__priority--" + it.priority}>{it.priority}</span>
              <span className="w360-mono">{it.time}</span>
            </div>
          </div>
        ))}
      </div>
    </aside>
  );
}

function ActionCard() {
  return (
    <div className="action-card">
      <div className="action-card__head">
        <span style={{ display: "inline-flex", width: 18, height: 18, borderRadius: "50%", background: "var(--w360-brand-500)", color: "#fff", alignItems: "center", justifyContent: "center", fontSize: 11 }}>!</span>
        Pending approval · plan 9d3a-71fc
      </div>

      <div style={{ fontSize: 13, color: "var(--n-700)", marginBottom: 12 }}>
        Trim Eleanor Vance's NVDA position from <strong>14.2%</strong> to <strong>9.5%</strong> of equity sleeve, ahead of FY27 Q1 earnings. Net proceeds redeployed to MAG-7 ex-NVDA per IPS §3.2.
      </div>

      <div className="action-card__plan">
        <div className="action-card__row"><span className="action-card__label">order</span><span className="action-card__value">SELL</span></div>
        <div className="action-card__row"><span className="action-card__label">symbol</span><span className="action-card__value">NVDA · NASDAQ</span></div>
        <div className="action-card__row"><span className="action-card__label">qty</span><span className="action-card__value">1,420 sh</span></div>
        <div className="action-card__row"><span className="action-card__label">est. proceeds</span><span className="action-card__value">~$300,003</span></div>
        <div className="action-card__row"><span className="action-card__label">tif</span><span className="action-card__value">DAY · LIMIT $211.10</span></div>
        <div className="action-card__row"><span className="action-card__label">venue</span><span className="action-card__value">MuleSoft · OMS-prime</span></div>
      </div>

      <div className="action-card__diff">
        <div style={{ fontSize: 10, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--n-500)", marginBottom: 4 }}>Concentration impact</div>
        <div className="action-card__diff-row"><span>NVDA / equity</span><span>14.2% <span className="action-card__diff-arrow">→</span> 9.5%</span></div>
        <div className="action-card__diff-row"><span>top-5 / equity</span><span>52.1% <span className="action-card__diff-arrow">→</span> 47.4%</span></div>
        <div className="action-card__diff-row"><span>policy band</span><span style={{ color: "var(--success-500)" }}>within ✓</span></div>
      </div>

      <div className="action-card__actions">
        <button className="btn-approve">Approve & submit</button>
        <button className="btn-edit">Edit plan</button>
        <button className="btn-deny">Deny</button>
        <span style={{ marginLeft: "auto", fontSize: 11, color: "var(--n-500)", alignSelf: "center" }}>
          ⌘↵ approve · ⌘⌫ deny · dual-auth required
        </span>
      </div>
    </div>
  );
}

function ConversationPanel() {
  return (
    <div className="advisor-col">
      <div className="advisor-col__header">
        <span>Eleanor Vance · Conversation</span>
        <span style={{ fontSize: 10, color: "var(--n-500)", textTransform: "none", letterSpacing: 0, fontWeight: 500 }}>turn 9d3a · plan in flight</span>
      </div>
      <div className="advisor-col__body">
        <div className="conversation">
          <div className="msg">
            <div className="msg__avatar msg__avatar--client">EV</div>
            <div className="msg__body">
              <div className="msg__header"><span className="msg__name">Eleanor Vance</span><span className="msg__time">06:09 · WhatsApp</span></div>
              <div className="msg__text">
                <p>Marcus, I've been watching NVDA closely. Should we be locking some gains before the print? I keep seeing the China headlines and it makes me nervous.</p>
              </div>
            </div>
          </div>

          <div className="msg">
            <div className="msg__avatar msg__avatar--user">MK</div>
            <div className="msg__body">
              <div className="msg__header"><span className="msg__name">Marcus Kerrigan</span><span className="msg__time">06:11</span></div>
              <div className="msg__text">
                <p>Eleanor — good instinct. NVDA is now 14.2% of your equity sleeve, above your IPS ceiling. Let me pull a trim plan and we'll review.</p>
              </div>
            </div>
          </div>

          <div className="msg">
            <div className="msg__avatar msg__avatar--ai">AI</div>
            <div className="msg__body">
              <div className="msg__header">
                <span className="msg__name">Workflow 360 · Advisor</span>
                <span className="msg__time">06:13 · drafted</span>
                <span className="w360-mono" style={{ fontSize: 10, color: "var(--w360-brand-500)", padding: "1px 6px", border: "1px solid var(--w360-brand-200)", borderRadius: 999 }}>action_specialist</span>
              </div>
              <div className="msg__text">
                <p>Drafted a partial-trim plan to bring NVDA from <strong>14.2% → 9.5%</strong> (mid of policy band). Sourced from research brief 4f8c, suitability screen passed, MNPI redactions applied. Awaiting your review.</p>
              </div>
              <ActionCard />
            </div>
          </div>
        </div>
      </div>
      <form className="composer">
        <textarea placeholder="Reply to Eleanor or instruct the agent…  /research /draft /schedule" defaultValue=""></textarea>
        <button type="button" className="btn-ghost" style={{ height: 36, padding: "0 12px" }}>+ attach</button>
        <button type="button" className="btn-brand" style={{ height: 36 }}>Send</button>
      </form>
    </div>
  );
}

function ClientContextPanel() {
  return (
    <aside className="advisor-col">
      <div className="advisor-col__header">
        <span>Client 360 · Eleanor Vance</span>
        <span style={{ fontSize: 10, color: "var(--success-500)", textTransform: "none", letterSpacing: 0 }}>● synced</span>
      </div>
      <div className="advisor-col__body client-context">
        <div className="client-context__head">
          <div className="client-context__avatar">EV</div>
          <div>
            <div className="client-context__name">Eleanor Vance</div>
            <div className="client-context__sub">Wealth · Tier-A · since 2009 · Boston</div>
          </div>
        </div>

        <div className="client-context__section">
          <div className="client-context__section-title">Holdings overview</div>
          <div className="client-context__row"><span className="client-context__row-label">Total AUM</span><span className="client-context__row-value">$8.42M</span></div>
          <div className="client-context__row"><span className="client-context__row-label">Unrealized P/L</span><span className="client-context__row-value" style={{ color: "var(--success-500)" }}>+$1.91M (+29.3%)</span></div>
          <div className="client-context__row"><span className="client-context__row-label">Cash sleeve</span><span className="client-context__row-value">$284K (3.4%)</span></div>
        </div>

        <div className="client-context__section">
          <div className="client-context__section-title">Allocation vs. IPS</div>
          <div className="client-context__alloc">
            <div className="client-context__alloc-seg" style={{ width: "62%", background: "#1B96FF" }}></div>
            <div className="client-context__alloc-seg" style={{ width: "22%", background: "#7B5A99" }}></div>
            <div className="client-context__alloc-seg" style={{ width: "9%", background: "#3B7A6E" }}></div>
            <div className="client-context__alloc-seg" style={{ width: "4%", background: "#B07A3D" }}></div>
            <div className="client-context__alloc-seg" style={{ width: "3%", background: "#706E6B" }}></div>
          </div>
          <div className="client-context__alloc-key">
            <div className="client-context__alloc-key-item"><span className="client-context__alloc-key-dot" style={{ background: "#1B96FF" }}></span>Equity 62% <span style={{ color: "var(--n-500)", fontSize: 10, marginLeft: 4 }}>(60±5)</span></div>
            <div className="client-context__alloc-key-item"><span className="client-context__alloc-key-dot" style={{ background: "#7B5A99" }}></span>Fixed inc. 22%</div>
            <div className="client-context__alloc-key-item"><span className="client-context__alloc-key-dot" style={{ background: "#3B7A6E" }}></span>Alts 9%</div>
            <div className="client-context__alloc-key-item"><span className="client-context__alloc-key-dot" style={{ background: "#B07A3D" }}></span>RE 4%</div>
            <div className="client-context__alloc-key-item"><span className="client-context__alloc-key-dot" style={{ background: "#706E6B" }}></span>Cash 3%</div>
          </div>
        </div>

        <div className="client-context__section">
          <div className="client-context__section-title">Top concentrations</div>
          <div className="client-context__row"><span className="client-context__row-label">NVDA</span><span className="client-context__row-value" style={{ color: "var(--warning-500)" }}>14.2% ⚠</span></div>
          <div className="client-context__row"><span className="client-context__row-label">MSFT</span><span className="client-context__row-value">11.8%</span></div>
          <div className="client-context__row"><span className="client-context__row-label">AAPL</span><span className="client-context__row-value">10.4%</span></div>
          <div className="client-context__row"><span className="client-context__row-label">GOOGL</span><span className="client-context__row-value">8.1%</span></div>
        </div>

        <div className="client-context__section">
          <div className="client-context__section-title">Recent signals</div>
          <div className="signal">
            <div className="signal__icon">⚑</div>
            <div>
              <div className="signal__title">Concentration breach (NVDA)</div>
              <div className="signal__desc">Above 12% IPS ceiling for 6 of last 10 closes.</div>
            </div>
          </div>
          <div className="signal">
            <div className="signal__icon" style={{ background: "var(--success-500)" }}>✓</div>
            <div>
              <div className="signal__title">Suitability re-attestation</div>
              <div className="signal__desc">Form ADV completed Apr 18 — current.</div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}

function AdvisorAuditStrip() {
  const spans = [
    ["advisor-orch", "ok", "var(--success-500)"],
    ["action-spec", "running", "var(--w360-brand-500)"],
    ["compliance-screen", "ok", "var(--success-500)"],
    ["mnpi-filter", "ok", "var(--success-500)"],
  ];
  return (
    <div className="audit-strip" style={{ background: "#021833" }}>
      <span style={{ color: "var(--forensic-text-4)" }}>trace</span>
      <span style={{ color: "var(--w360-brand-500)" }}>9d3a-71fc-44b2</span>
      <span style={{ color: "var(--forensic-text-4)" }}>·</span>
      <span style={{ color: "var(--success-300)" }}>● ws: open</span>
      <span style={{ color: "var(--forensic-text-4)" }}>·</span>
      <span style={{ color: "var(--warning-300)" }}>⏸ HITL hold · gate ④</span>
      <span style={{ color: "var(--forensic-text-4)" }}>·</span>
      {spans.map(([n, s, c]) => (
        <span key={n} className="audit-pill" style={{ borderColor: `${c}88`, color: c }}>{n} <span className="audit-pill__status">{s}</span></span>
      ))}
      <span style={{ marginLeft: "auto", color: "var(--forensic-text-4)" }}>plan held 11.4s · 7 spans · ⌥L Langfuse</span>
    </div>
  );
}

function AdvisorWorkbench() {
  return (
    <div className="advisor-root" data-screen-label="02 RM Advisor Workbench">
      <PersonaHeader persona="Advisor" user="Marcus Kerrigan · Sr. Wealth Advisor" avatar="MK" navActive="Advisor" />
      <GatesTracker activeIdx={3} />
      <div className="advisor-body">
        <QueuesPanel />
        <ConversationPanel />
        <ClientContextPanel />
      </div>
      <div className="trust-spine">
        <div className="trust-spine__eyebrow">
          <span><strong>Trust spine</strong> · same orchestrator graph as Sarah's research, now lit through advisor_orch</span>
          <span className="w360-mono">conversation 4f8c-2a11 → plan 9d3a-71fc · gate ④ HITL</span>
        </div>
        <window.TraversalMap persona="advisor" turnId="9d3a-71fc" />
        <window.Timeline persona="advisor" />
      </div>
      <AdvisorAuditStrip />
    </div>
  );
}

window.AdvisorWorkbench = AdvisorWorkbench;
