/* global React */
const { useState, useEffect } = React;

/* =========================================================================
 * RESEARCH TERMINAL — Sarah Chen
 * Dark forensic surface. Brief streaming, citations, parallel architecture
 * map, mini-timeline waterfall, audit strip.
 * ========================================================================= */

function W360Logo({ size = 18 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" stroke="#1B96FF" strokeWidth="1.6" />
      <path d="M12 2v20M2 12h20" stroke="#1B96FF" strokeWidth="1" opacity=".4" />
      <circle cx="12" cy="12" r="3.5" fill="#1B96FF" />
    </svg>
  );
}

function PersonaHeader({ persona, user, avatar, navActive }) {
  const items = ["Research", "Advisor", "Liaison"];
  return (
    <header className="persona-header">
      <div className="persona-header__brand">
        <div className="persona-header__logo"><W360Logo /> Workflow 360</div>
        <span style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>{persona}</span>
        <nav className="persona-header__nav">
          {items.map(i => <a key={i} href="#" className={i === navActive ? "is-active" : ""}>{i}</a>)}
        </nav>
      </div>
      <div className="persona-header__user">
        <span className="live-dot">connected</span>
        <span style={{ color: "rgba(255,255,255,0.7)" }}>{user}</span>
        <span className="persona-header__avatar">{avatar}</span>
      </div>
    </header>
  );
}

function CiteChip({ n, pending, onClick }) {
  return (
    <span
      className={"chip-cite" + (pending ? " chip-cite--pending" : "")}
      onClick={onClick}
      role="button"
      tabIndex={0}
    >{n}</span>
  );
}

function Pane({ title, status, statusKind, right, children, flex }) {
  return (
    <div className="pane" style={flex ? { flex } : undefined}>
      <div className="pane__header">
        <span>{title}</span>
        {status && <span className={"pane__status " + (statusKind ? `pane__status--${statusKind}` : "")}>● {status}</span>}
        {right}
      </div>
      <div className="pane__body">{children}</div>
    </div>
  );
}

/* ---------- Brief content ---------- */
function BriefContent({ openCite }) {
  return (
    <div className="research-brief">
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 14 }}>
        <span className="chip-running">sec-edgar · 412ms</span>
        <span className="chip-running">finnhub-mcp · 280ms</span>
        <span className="chip-running">tavily-news · running</span>
        <span className="chip-running">compliance-screen · 110ms</span>
      </div>

      <h2>NVIDIA — Earnings Setup, Q1 FY27</h2>
      <p>
        Data-center revenue grew <strong>62% YoY</strong> in the most recent 10-Q, driven by Hopper-to-Blackwell mix shift and a record <strong>$33.4B</strong> segment quarter <CiteChip n="1" onClick={openCite} />. Forward guide implies a step-up to <strong>~$36–37B</strong> next quarter, bracketed by supply commentary in prepared remarks <CiteChip n="2" onClick={openCite} />.
      </p>
      <p>
        China exposure remains the principal structural risk. Management disclosed a <strong>$5.5B Q4 charge</strong> tied to H20 export controls; the same controls now extend to B40-class parts <CiteChip n="3" onClick={openCite} />. Compliance specialist confirms NVDA is not on the firm's restricted list <CiteChip n="4" pending />.
      </p>

      <div className="brief-callout">
        <div className="brief-callout__label">⚑ MNPI redaction applied</div>
        Two CRM notes from the Insights desk were withheld from this brief by the trust spine (`mnpi_filter` gate). Unredacted version available on request with elevated entitlements.
      </div>

      <p>
        Sentiment tilted constructive over the trailing 30 days (76 articles, <strong>+0.41 mean</strong>), but dispersion widens around any China headline. Sell-side consensus has drifted from $0.86 → $0.91 over the same window <CiteChip n="5" onClick={openCite} />.
      </p>

      <div className="brief-chart">
        <div className="brief-chart__title">
          <span className="w360-label" style={{ color: "var(--forensic-text-3)" }}>Data-center revenue · quarterly · $B</span>
          <span className="w360-mono" style={{ fontSize: 10, color: "var(--forensic-text-5)" }}>source: 10-Q · table 4 · clickable</span>
        </div>
        <svg width="100%" height="130" viewBox="0 0 600 130" preserveAspectRatio="none">
          <line x1="0" y1="115" x2="600" y2="115" stroke="#1C2B3F" />
          {[14.5, 18.4, 22.6, 26.3, 30.8, 33.4, 36.5].map((v, i) => {
            const h = (v / 40) * 100;
            const x = 24 + i * 82;
            const isGuide = i === 6;
            const isLatest = i === 5;
            return (
              <g key={i}>
                <rect
                  x={x} y={115 - h} width={56} height={h}
                  fill={isGuide ? "transparent" : (isLatest ? "#1B96FF" : "#284872")}
                  stroke={isGuide ? "#1B96FF" : "none"}
                  strokeDasharray={isGuide ? "3 3" : ""}
                  strokeWidth={isGuide ? 1.5 : 0}
                />
                <text x={x + 28} y={115 - h - 6} textAnchor="middle" fontSize="11" fill={isLatest ? "#fff" : "#9FB6CF"} fontFamily="JetBrains Mono">{v}</text>
                <text x={x + 28} y="128" textAnchor="middle" fontSize="10" fill="#6E7681" fontFamily="JetBrains Mono">{["Q3","Q4","Q1","Q2","Q3","Q4","Q1e"][i]}</text>
              </g>
            );
          })}
        </svg>
      </div>

      <h3>Risk dispersion · 12-mo</h3>
      <p>
        Implied vol skew for NVDA earnings has tightened from 38v / 30c to 31v / 28c since the last print, but tail-risk premium remains elevated relative to MAG-7 cohort mean <CiteChip n="6" onClick={openCite} />.
      </p>
    </div>
  );
}

/* ---------- Architecture map (local, unused — see trace-shared.jsx) ---------- */
function TraversalMap_LEGACY_UNUSED() {
  const nodes = {
    coord: { x: 600, y: 14, label: "COORDINATOR", status: "solid", chip: "coordinator" },
    research: { x: 600, y: 56, label: "ORCHESTRATOR", status: "pulse", chip: "research_orchestrator" },
    market: { x: 110, y: 110, label: "specialist", status: "solid", chip: "market_spec" },
    filings: { x: 290, y: 110, label: "specialist", status: "solid", chip: "filings_spec" },
    sent: { x: 470, y: 110, label: "specialist", status: "pulse", chip: "sentiment_spec" },
    compl: { x: 660, y: 110, label: "specialist", status: "solid", chip: "compliance_spec" },
    stmt: { x: 850, y: 110, label: "specialist", status: "solid", chip: "statement_spec" },
    advisor: { x: 1080, y: 56, label: "ORCHESTRATOR", status: "dim", chip: "advisor_orch" },
    liaison: { x: 1080, y: 110, label: "ORCHESTRATOR", status: "dim", chip: "liaison_orch" },

    finnhub: { x: 110, y: 165, label: "MCP", status: "solid", chip: "finnhub" },
    edgar1: { x: 290, y: 165, label: "MCP", status: "solid", chip: "sec-edgar" },
    tavily: { x: 470, y: 165, label: "MCP", status: "pulse", chip: "tavily" },
    cscreen: { x: 660, y: 165, label: "skill", status: "solid", chip: "compliance_screen" },
    edgar2: { x: 850, y: 165, label: "MCP", status: "solid", chip: "sec-edgar" },
  };
  const edges = [
    ["coord", "research", "lit"],
    ["research", "market", "lit"],
    ["research", "filings", "lit"],
    ["research", "sent", "dashed"],
    ["research", "compl", "lit"],
    ["research", "stmt", "lit"],
    ["coord", "advisor", "dim"],
    ["coord", "liaison", "dim"],
    ["market", "finnhub", "lit"],
    ["filings", "edgar1", "lit"],
    ["sent", "tavily", "dashed"],
    ["compl", "cscreen", "lit"],
    ["stmt", "edgar2", "lit"],
  ];

  return (
    <div className="traversal-map">
      <div className="tm-header">
        <div className="tm-header__title">
          <span>Architecture Map</span>
          <span className="w360-mono" style={{ fontSize: 10, color: "var(--forensic-text-4)", textTransform: "none", letterSpacing: 0 }}>persona: research · turn 4f8c-2a11 · 5 specialists in parallel</span>
        </div>
        <div className="tm-header__legend">
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#3B4A5F" }}></span>dim</span>
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#1B96FF", boxShadow: "0 0 8px #1B96FF" }}></span>in-flight</span>
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#56D364" }}></span>complete</span>
          <span className="tm-legend-item"><span className="tm-legend-dot" style={{ background: "#F47067" }}></span>error</span>
        </div>
      </div>
      <div className="tm-canvas">
        <svg width="100%" height="100%" viewBox="0 0 1240 200" preserveAspectRatio="none" style={{ position: "absolute", inset: 0 }}>
          {edges.map(([from, to, kind], i) => {
            const f = nodes[from], t = nodes[to];
            const cls = kind === "lit" ? "tm-edge tm-edge--lit" : kind === "dashed" ? "tm-edge--lit-dashed" : "tm-edge";
            const fx = f.x + 50, fy = f.y + 14;
            const tx = t.x + 50, ty = t.y;
            const my = (fy + ty) / 2;
            return (
              <path key={i} className={cls} d={`M${fx},${fy} C${fx},${my} ${tx},${my} ${tx},${ty}`} />
            );
          })}
        </svg>
        {Object.entries(nodes).map(([key, n]) => (
          <div key={key} className="tm-node" data-status={n.status} style={{ left: n.x, top: n.y }}>
            <div className="tm-node__chip">{n.chip}</div>
            <div className="tm-node__label">{n.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------- Mini-timeline (local, unused — see trace-shared.jsx) ---------- */
function Timeline_LEGACY_UNUSED() {
  // Each row: name, kind, start%, length%, latency, ok
  const rows = [
    ["research_orchestrator", "orch", 0, 99, "2310ms"],
    ["├ market_specialist", "skill", 4, 40, "920ms"],
    ["│  └ finnhub-mcp", "mcp", 8, 12, "280ms"],
    ["├ filings_specialist", "skill", 4, 51, "1180ms"],
    ["│  └ sec-edgar-mcp", "mcp", 12, 18, "412ms"],
    ["├ sentiment_specialist", "skill", 5, 36, "840ms"],
    ["│  └ tavily-mcp", "mcp", 9, 15, "340ms"],
    ["├ compliance_specialist", "skill", 4, 27, "620ms"],
    ["│  └ compliance_screen", "skill", 8, 5, "110ms"],
    ["└ statement_specialist", "skill", 5, 57, "1320ms"],
    ["    └ sec-edgar-mcp", "mcp", 14, 21, "490ms"],
  ];
  return (
    <div className="timeline">
      <div className="timeline__header">
        <div className="timeline__header-title">
          <span>End-to-End Trace</span>
          <span className="w360-mono" style={{ fontSize: 10, color: "var(--forensic-text-4)", textTransform: "none", letterSpacing: 0 }}>06:14:30 · "What's happening with NVDA?" · 5 tools · 2.3s</span>
        </div>
        <button className="btn-ghost">⎋ open in Langfuse</button>
      </div>
      <div className="timeline__rows">
        {rows.map(([name, kind, start, len, lat], i) => (
          <div key={i} className="timeline__row">
            <span className={"timeline__name" + (name.startsWith("├") || name.startsWith("│") || name.startsWith("└") || name.startsWith("    ") ? " timeline__name--child" : "")}>{name}</span>
            <span className="timeline__type">[{kind}]</span>
            <div className="timeline__bar-track">
              <div
                className={"timeline__bar timeline__bar--" + kind}
                style={{ left: `${start}%`, width: `${len}%` }}
              />
            </div>
            <span className="timeline__latency">{lat}</span>
          </div>
        ))}
      </div>
      <div className="timeline__caption">
        All five specialists started at t≈80ms — proves <span className="w360-mono">asyncio.gather</span>. Orchestrator total ≠ Σ children — proves parallelism.
      </div>
    </div>
  );
}

/* ---------- Right column panes ---------- */
function MarketPane() {
  return (
    <Pane title="Market · NVDA" status="live" statusKind="streaming">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 4 }}>
        <span style={{ fontSize: 22, fontWeight: 700, color: "#fff" }}>NVDA</span>
        <span className="w360-mono" style={{ fontSize: 22, color: "var(--success-300)", fontWeight: 600 }}>$211.27</span>
      </div>
      <div className="w360-mono" style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "var(--forensic-text-3)" }}>
        <span style={{ color: "var(--success-300)" }}>+3.42 (+1.65%)</span>
        <span>vol 38.2M</span>
      </div>
      <svg width="100%" height="56" viewBox="0 0 320 56" style={{ marginTop: 8 }}>
        <defs>
          <linearGradient id="sparkfill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor="#56D364" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#56D364" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path
          d="M0,40 L20,38 L40,42 L60,32 L80,34 L100,28 L120,30 L140,22 L160,24 L180,16 L200,18 L220,14 L240,18 L260,10 L280,8 L300,12 L320,6 L320,56 L0,56 Z"
          fill="url(#sparkfill)"
        />
        <polyline fill="none" stroke="#56D364" strokeWidth="1.5"
          points="0,40 20,38 40,42 60,32 80,34 100,28 120,30 140,22 160,24 180,16 200,18 220,14 240,18 260,10 280,8 300,12 320,6" />
      </svg>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginTop: 12, fontSize: 11 }}>
        {[["1D", "+1.65%", "var(--success-300)"], ["5D", "+4.21%", "var(--success-300)"], ["1M", "−2.18%", "var(--error-300)"], ["YTD", "+38.4%", "var(--success-300)"]].map(([k, v, c]) => (
          <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "4px 8px", background: "var(--forensic-elevated)", borderRadius: 3 }}>
            <span style={{ color: "var(--forensic-text-4)" }}>{k}</span>
            <span className="w360-mono" style={{ color: c, fontWeight: 600 }}>{v}</span>
          </div>
        ))}
      </div>
    </Pane>
  );
}

function FilingsPane() {
  const rows = [
    ["10-Q", "FY26 Q3", "Item 7 · MD&A", "p.42"],
    ["10-K", "FY26", "Item 1A · Risk Factors", "p.18"],
    ["8-K", "Apr 14", "Export-control charge", "—"],
    ["DEF 14A", "FY26", "Comp · NEO", "p.31"],
    ["10-Q", "FY26 Q2", "Item 7 · Liquidity", "p.39"],
  ];
  return (
    <Pane title="Filings · 10 chunks indexed" right={<span style={{ fontSize: 10, color: "var(--forensic-text-4)" }}>EDGAR · live</span>}>
      <div style={{ display: "grid", gridTemplateColumns: "auto 1fr auto", gap: "4px 12px", fontSize: 12 }}>
        {rows.map(([type, date, sec, page], i) => (
          <React.Fragment key={i}>
            <span className="w360-mono" style={{ color: "var(--w360-brand-500)", fontSize: 10.5, padding: "4px 6px", borderRadius: 2, background: "rgba(27,150,255,0.08)", border: "1px solid rgba(27,150,255,0.2)", display: "inline-block", textAlign: "center" }}>{type}</span>
            <div>
              <div style={{ color: "#fff", fontSize: 12, fontWeight: 500 }}>{sec}</div>
              <div className="w360-mono" style={{ color: "var(--forensic-text-4)", fontSize: 10 }}>{date} · {page}</div>
            </div>
            <span style={{ color: "var(--forensic-text-5)", fontSize: 10, alignSelf: "center" }}>↗</span>
          </React.Fragment>
        ))}
      </div>
    </Pane>
  );
}

function SentimentPane() {
  return (
    <Pane title="Sentiment · 30d" status="76 articles" statusKind="idle">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
        <span className="w360-mono" style={{ fontSize: 26, fontWeight: 700, color: "var(--success-300)" }}>+0.41</span>
        <span style={{ fontSize: 11, color: "var(--forensic-text-3)" }}>σ 0.28 · n=76</span>
      </div>
      <svg width="100%" height="48" viewBox="0 0 320 48">
        <line x1="0" y1="24" x2="320" y2="24" stroke="#1C2B3F" />
        {Array.from({ length: 30 }).map((_, i) => {
          const v = Math.sin(i / 3) * 9 + Math.cos(i) * 4;
          return (
            <line
              key={i}
              x1={i * 11 + 4} y1={24}
              x2={i * 11 + 4} y2={24 - v}
              stroke={v > 0 ? "#56D364" : "#F47067"}
              strokeWidth="2.5"
            />
          );
        })}
      </svg>
      <div style={{ marginTop: 10, fontSize: 11, color: "var(--forensic-text-3)" }}>
        Top topics: <span style={{ color: "var(--w360-brand-500)" }}>blackwell mix</span>, <span style={{ color: "var(--w360-brand-500)" }}>china export</span>, <span style={{ color: "var(--w360-brand-500)" }}>capex guide</span>
      </div>
    </Pane>
  );
}

function DemandPane() {
  const items = [
    ["Pre-earnings · NVDA", "RM Marcus K. · 3 clients", "high"],
    ["Sector pulse · semis", "RM Priya S.", "med"],
    ["China supply ripple", "Insights desk", "med"],
  ];
  return (
    <Pane title="Demand Signals">
      {items.map(([t, s, p], i) => (
        <div key={i} style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", padding: "8px 0", borderBottom: i < items.length - 1 ? "1px solid var(--forensic-line)" : "0", gap: 8 }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ color: "#fff", fontSize: 12, fontWeight: 500 }}>{t}</div>
            <div className="w360-mono" style={{ color: "var(--forensic-text-4)", fontSize: 10 }}>{s}</div>
          </div>
          <button className="btn-ghost" style={{ fontSize: 10, padding: "3px 8px" }}>accept →</button>
        </div>
      ))}
    </Pane>
  );
}

/* ---------- Audit strip ---------- */
function AuditStrip() {
  const spans = [
    ["research-orch", "ok", "var(--success-300)"],
    ["market-spec", "ok", "var(--success-300)"],
    ["filings-spec", "ok", "var(--success-300)"],
    ["sent-spec", "running", "var(--warning-300)"],
    ["compl-spec", "ok", "var(--success-300)"],
    ["stmt-spec", "ok", "var(--success-300)"],
  ];
  return (
    <div className="audit-strip">
      <span style={{ color: "var(--forensic-text-4)" }}>trace</span>
      <span style={{ color: "var(--w360-brand-500)" }}>4f8c-2a11-d8e1</span>
      <span style={{ color: "var(--forensic-text-4)" }}>·</span>
      <span style={{ color: "var(--success-300)" }}>● ws: open</span>
      <span style={{ color: "var(--forensic-text-4)" }}>·</span>
      {spans.map(([n, s, c]) => (
        <span key={n} className="audit-pill" style={{ borderColor: `${c}55`, color: c }}>
          {n} <span className="audit-pill__status">{s}</span>
        </span>
      ))}
      <span style={{ marginLeft: "auto", color: "var(--forensic-text-4)" }}>turn 2.31s · 11 spans · cost $0.082 · ⌥L Langfuse</span>
    </div>
  );
}

/* ---------- Root ---------- */
function ResearchTerminal() {
  return (
    <div className="research-root surface-forensic" data-screen-label="01 Research Terminal">
      <PersonaHeader persona="Research" user="Sarah Chen · Sr. Equity Analyst" avatar="SC" navActive="Research" />
      <div className="research-toolbar">
        <div className="research-query">
          <input
            className="research-query__input"
            defaultValue="Research NVDA ahead of earnings — focus on data-center revenue mix and China exposure"
            aria-label="Research query"
          />
          <button className="btn-brand">Run ⌘↵</button>
        </div>
        <button className="btn-ghost">{`{ }`} JSON</button>
        <button className="btn-ghost">⤓ export brief</button>
      </div>
      <div className="research-body">
        <Pane title="Brief — citation-enforced" status="streaming…" statusKind="streaming" right={<span style={{ fontSize: 10, color: "var(--forensic-text-4)" }}>4 of 5 specialists complete</span>}>
          <BriefContent />
        </Pane>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, minHeight: 0 }}>
          <MarketPane />
          <FilingsPane />
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, minHeight: 0 }}>
          <SentimentPane />
          <DemandPane />
        </div>
      </div>
      <window.TraversalMap persona="research" />
      <window.Timeline persona="research" />
      <AuditStrip />
    </div>
  );
}

window.ResearchTerminal = ResearchTerminal;
window.PersonaHeader = PersonaHeader;
window.W360Logo = W360Logo;
